//
//  bank.h
//  bankers
//
//  Created by William McCarthy on 1011//20.
//

#ifndef bankImpl_h
#define bankImpl_h

#include "customer.h"
//#include <iomanip>
//#include <vector>


class BankImpl {
public:
  BankImpl() = default;
  BankImpl(const ext_vector<int>& available) : avail(available), customers() { }
  
  ext_vector<int> get_avail() const { return avail; }
  bool is_avail(const ext_vector<int>& req) const { return req < avail; }
  
  bool is_safe(int id, const ext_vector<int>& req) {
    return req < (customers[id])->get_need();
  }

  bool req_approved(int id, const ext_vector<int>& req) { 
    pthread_mutex_lock(&mutex_);
    std::cout << "Requesting: [" << req << " ] from P#" << id << " ...\t";
    
    if (req > avail) {
      std::cout << "Request Failed\n";
      pthread_mutex_unlock(&mutex_);
      return false;
    }
    if (req > customers[id]->get_need()) {
      std::cout << "Request Failed\n";
      pthread_mutex_unlock(&mutex_);
      return false;
    }
    if (req <= customers[id]->get_need()) {
      std::cout << "Request Passed\n";
      pthread_mutex_unlock(&mutex_);
      return true;
    }
    /* if(is_avail(req))
      if(is_safe(id, req)) {
        pthread_mutex_unlock(&mutex_);
        return true;
      }
    else {
      pthread_mutex_unlock(&mutex_);
      return false;
    } */
  }
  
  void add_customer(Customer* c) { customers.push_back(c); }
  
  void withdraw_resources(const ext_vector<int>& req) {
    if (!is_avail(req)) {
      pthread_mutex_lock(&mutex_);
      std::cerr << "WARNING: req: " << req << " is not available for withdrawing\n";
      pthread_mutex_unlock(&mutex_);
      return;
    }
    pthread_mutex_lock(&mutex_);
    if (is_avail(req)) { avail -= req; }
    pthread_mutex_unlock(&mutex_);
  }
  void deposit_resources(const ext_vector<int>& req) { avail += req; }


  ext_vector<Customer*> get_customers() const { return customers; }
  
  void show() const {
    pthread_mutex_lock(&mutex_);
    std::cout << "avail: [" << avail << " ]\n";

    std::cout << std::setw(10) <<"Allocated" << std::setw(16) << "Max\tNeed\n";
    
    pthread_mutex_unlock(&mutex_);
    for (Customer* c : customers) {
      c->show();
    }
    std::cout << "\n";
  }
  
  friend std::ostream& operator<<(std::ostream& os, const BankImpl& be) {
    be.show();
    return os;
  }

private:
  ext_vector<int> avail;
  ext_vector<Customer*> customers;
  bool running;
};

#endif /* bank_h */
