
#include <cstdlib>
#include <ctime>
#include <thread>
#include <exception>


class sleep_util {
public:
    static const int SLEEP_TIME = 4;

    sleep_util() = default;

    static void short_sleep() {
        int sleeptime = 1 + (int)(SLEEP_TIME * rand() / RAND_MAX);
        short_sleep(sleeptime);     // sleep between zero and SLEEP_TIME
    }

    static void short_sleep(int duration) {
        try {
            std::this_thread::sleep_for(std::chrono::seconds(duration));
        }
        catch (std::exception e) { throw e; }
    }
};

#pragma once
